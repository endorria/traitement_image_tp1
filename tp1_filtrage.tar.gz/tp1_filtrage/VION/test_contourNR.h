/* ------------------------ */
/* --- test_contourNR.c --- */
/* ------------------------ */

/*
 * Copyright (c) 2011 Lionel Lacassagne, all rights reserved
 * University Paris Sud 11
 */

#ifndef __TEST_CONTOUR_NR_H__
#define __TEST_CONTOUR_NR_H__

#ifdef __cplusplus
extern "C" {
#endif
    
int test_contourNR(int argc, const char * argv[]);

#ifdef __cplusplus
}
#endif

#endif // __TEST_CONTOUR_NR_H__