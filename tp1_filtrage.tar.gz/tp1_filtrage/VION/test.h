/* -------------- */
/* --- test.h --- */
/* -------------- */

/*
 * Copyright (c) 2011 Lionel Lacassagne, all rights reserved
 * University Paris Sud 11
 */

#ifndef __TEST_H__
#define __TEST_H__

#ifdef __cplusplus
extern "C" {
#endif
    
int test (int argc, const char * argv[]);

#ifdef __cplusplus
}
#endif

#endif // __TEST_H__